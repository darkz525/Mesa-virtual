
const socket = io();

// Referências HTML
const addFichaBtn = document.getElementById('addFicha');
const fichaList = document.getElementById('fichaList');
const uploadMap = document.getElementById('uploadMap');
const mapCanvas = document.getElementById('mapCanvas');
const ctx = mapCanvas.getContext('2d');

// Fichas de Personagens
const fichas = [];

addFichaBtn.addEventListener('click', () => {
  const fichaName = prompt('Digite o nome do personagem:');
  if (fichaName) {
    const ficha = { id: Date.now(), name: fichaName, attributes: {} };
    fichas.push(ficha);
    renderFichas();
    socket.emit('newFicha', { roomId: roomIdSpan.textContent, ficha });
  }
});

function renderFichas() {
  fichaList.innerHTML = '';
  fichas.forEach((ficha) => {
    const fichaDiv = document.createElement('div');
    fichaDiv.textContent = ficha.name;
    fichaList.appendChild(fichaDiv);
  });
}

// Mapas Interativos
let mapImage = null;

uploadMap.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      mapImage = new Image();
      mapImage.onload = () => {
        mapCanvas.width = mapImage.width;
        mapCanvas.height = mapImage.height;
        ctx.drawImage(mapImage, 0, 0);
        socket.emit('mapUpdate', { roomId: roomIdSpan.textContent, mapData: e.target.result });
      };
      mapImage.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
});

// Atualizar mapa recebido do servidor
socket.on('mapUpdate', (data) => {
  const img = new Image();
  img.onload = () => {
    mapCanvas.width = img.width;
    mapCanvas.height = img.height;
    ctx.drawImage(img, 0, 0);
  };
  img.src = data.mapData;
});

// Atualizar fichas recebidas do servidor
socket.on('newFicha', (data) => {
  fichas.push(data.ficha);
  renderFichas();
});

// Rolagem de Dados
const diceType = document.getElementById('diceType');
const diceCount = document.getElementById('diceCount');
const rollDiceBtn = document.getElementById('rollDice');
const diceResults = document.getElementById('diceResults');

rollDiceBtn.addEventListener('click', () => {
  const type = parseInt(diceType.value, 10);
  const count = parseInt(diceCount.value, 10);
  if (count > 0 && type > 0) {
    const results = [];
    for (let i = 0; i < count; i++) {
      results.push(Math.floor(Math.random() * type) + 1);
    }
    const total = results.reduce((sum, val) => sum + val, 0);

    // Enviar para os outros jogadores
    socket.emit('rollDice', {
      roomId: roomIdSpan.textContent,
      results,
      total,
      type,
      count,
    });

    // Exibir resultado localmente
    displayDiceRoll({ results, total, type, count, sender: 'Você' });
  }
});

// Exibir resultado de dados
function displayDiceRoll({ results, total, type, count, sender }) {
  const li = document.createElement('li');
  li.textContent = `${sender} rolou ${count}d${type}: [${results.join(', ')}] Total: ${total}`;
  diceResults.appendChild(li);
}

// Receber rolagens de outros jogadores
socket.on('rollDice', (data) => {
  displayDiceRoll({ ...data, sender: 'Outro jogador' });
});
